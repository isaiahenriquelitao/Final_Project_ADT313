function Section(){
    return(<div>
        <h1>BSIT 3B</h1>
    </div>)
}
export default Section
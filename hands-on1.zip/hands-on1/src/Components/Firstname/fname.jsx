function Firstname(){
    return(<div>
        <h1>Isaiah Enrique</h1>
    </div>)
}
export default Firstname
import { useState, useRef, useCallback, useEffect } from 'react';
import './Register.css';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from '../../../utils/hooks/useDebounce';
import axios from 'axios';

const Register = () => {
  const [userData, setUserData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    middleName: '',
    lastName: '',
    contactNo: ''
  });
  
  const [isDirty, setIsDirty] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [status, setStatus] = useState('idle');
  const [debouncedInput, setDebouncedInput] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const inputRefs = {
    email: useRef(),
    password: useRef(),
    confirmPassword: useRef(),
    firstName: useRef(),
    middleName: useRef(),
    lastName: useRef(),
    contactNo: useRef()
  };

  const userInputDebounce = useDebounce(userData, 2000);
  const navigate = useNavigate();

  const togglePasswordVisibility = useCallback(() => {
    setIsPasswordVisible(prev => !prev);
  }, []);

  const handleInputChange = (event, field) => {
    setIsDirty(true);
    setDebouncedInput(false);

    setUserData(prevData => ({
      ...prevData,
      [field]: event.target.value
    }));
  };

  const handleRegister = async () => {
    if (userData.password !== userData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    const { email, password, firstName, middleName, lastName, contactNo } = userData;
    const payload = { email, password, firstName, middleName, lastName, contactNo };
    
    setStatus('loading');

    try {
      const response = await axios.post('/admin/register', payload, {
        headers: { 'Access-Control-Allow-Origin': '*' }
      });

      console.log(response);
      localStorage.setItem('accessToken', response.data.access_token);
      setSuccessMessage('Registration Successful! Redirecting...');
      
      setTimeout(() => navigate('/main/movies'), 2000);

      setUserData({
        email: '',
        password: '',
        confirmPassword: '',
        firstName: '',
        middleName: '',
        lastName: '',
        contactNo: ''
      });

      setStatus('idle');
    } catch (error) {
      console.log(error);
      setStatus('idle');
    }
  };

  useEffect(() => {
    setDebouncedInput(true);
  }, [userInputDebounce]);

  const isFieldEmpty = (field) => userData[field] === '';

  return (
    <div className="Register">
      <div className="main-container">
        <h3>Register</h3>
        <form>
          <div className="register-form-container">
            {['firstName', 'middleName', 'lastName', 'contactNo', 'email'].map((field) => (
              <div key={field}>
                <div className="register-form-group">
                  <label>{field.charAt(0).toUpperCase() + field.slice(1).replace(/([A-Z])/g, ' $1')}:</label>
                  <input
                    type="text"
                    name={field}
                    ref={inputRefs[field]}
                    onChange={(e) => handleInputChange(e, field)}
                  />
                </div>
                {debouncedInput && isDirty && isFieldEmpty(field) && (
                  <span className="errors">This field is required</span>
                )}
              </div>
            ))}

            <div>
              <div className="register-form-group">
                <label>Password:</label>
                <input
                  type={isPasswordVisible ? 'text' : 'password'}
                  name="password"
                  ref={inputRefs.password}
                  onChange={(e) => handleInputChange(e, 'password')}
                />
              </div>
              {debouncedInput && isDirty && isFieldEmpty('password') && (
                <span className="errors">This field is required</span>
              )}
            </div>

            <div>
              <div className="register-form-group">
                <label>Confirm Password:</label>
                <input
                  type={isPasswordVisible ? 'text' : 'password'}
                  name="confirmPassword"
                  ref={inputRefs.confirmPassword}
                  onChange={(e) => handleInputChange(e, 'confirmPassword')}
                />
              </div>
              {debouncedInput && isDirty && isFieldEmpty('confirmPassword') && (
                <span className="errors">This field is required</span>
              )}
              {userData.password !== userData.confirmPassword && userData.confirmPassword && (
                <span className="errors">Passwords do not match</span>
              )}
            </div>

            <div className="show-password" onClick={togglePasswordVisibility}>
              {isPasswordVisible ? 'Hide' : 'Show'} Password
            </div>

            <div className="submit-container">
              <button
                type="button"
                disabled={status === 'loading'}
                onClick={() => {
                  if (status === 'loading') return;

                  const requiredFields = ['email', 'password', 'confirmPassword', 'firstName', 'lastName'];
                  const missingField = requiredFields.find(field => isFieldEmpty(field));

                  if (!missingField) {
                    handleRegister();
                  } else {
                    setIsDirty(true);
                    inputRefs[missingField].current.focus();
                  }
                }}
              >
                {status === 'idle' ? 'Register' : 'Loading'}
              </button>
            </div>

            {successMessage && <div className="success-message">{successMessage}</div>}
            <div className="login-container">
              <a href="/">
                <small>Login</small>
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;

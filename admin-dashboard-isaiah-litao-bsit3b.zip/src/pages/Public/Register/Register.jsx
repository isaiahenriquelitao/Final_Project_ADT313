import { useState, useRef, useCallback, useEffect } from 'react';
import './Register.css';
import { useNavigate } from 'react-router-dom';
import { useDebounce } from '../../../utils/hooks/useDebounce';
import axios from 'axios';

const Register = () => {
  const [userData, setUserData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    middleName: '',
    lastName: '',
    contactNo: ''
  });
  
  const [isDirty, setIsDirty] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [status, setStatus] = useState('idle');
  const [contactError, setContactError] = useState('');

  const inputRefs = {
    email: useRef(),
    password: useRef(),
    confirmPassword: useRef(),
    firstName: useRef(),
    middleName: useRef(),
    lastName: useRef(),
    contactNo: useRef()
  };

  const userInputDebounce = useDebounce(userData, 1000);
  const navigate = useNavigate();

  const togglePasswordVisibility = useCallback(() => {
    setIsPasswordVisible(prev => !prev);
  }, []);

  const handleInputChange = (event, field) => {
    setIsDirty(true);

    if (field === 'contactNo') {
      const value = event.target.value;
      if (!/^\d{0,11}$/.test(value)) {
        alert('Contact number must be numeric and up to 11 digits.');
      } else {
        setContactError('');
      }
    }

    setUserData(prevData => ({
      ...prevData,
      [field]: event.target.value
    }));
  };

  const handleRegister = async () => {
    if (userData.password !== userData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    if (userData.contactNo.length !== 11) {
      alert('Contact number must be exactly 11 digits.');
      return;
    }

    const { email, password, firstName, middleName, lastName, contactNo } = userData;
    const payload = { email, password, firstName, middleName, lastName, contactNo };
    
    setStatus('loading');

    try {
      const response = await axios.post('/admin/register', payload, {
        headers: { 'Access-Control-Allow-Origin': '*' }
      });

      console.log(response);
      localStorage.setItem('accessToken', response.data.access_token);
      alert('Registration Successful! You can now log in.');

      setTimeout(() => navigate('/'), 2000);

      setUserData({
        email: '',
        password: '',
        confirmPassword: '',
        firstName: '',
        middleName: '',
        lastName: '',
        contactNo: ''
      });

      setStatus('idle');
    } catch (error) {
      if (error.response && error.response.status === 409) { 
        alert('Email already exists. Please use a different email.');
      } else {
        console.log(error);
      }
      setStatus('idle');
    }
  };

  useEffect(() => {}, [userInputDebounce]);

  const isFieldEmpty = (field) => userData[field] === '';

  const handleSubmit = () => {
    const requiredFields = ['email', 'password', 'confirmPassword', 'firstName', 'lastName', 'contactNo'];
    const missingField = requiredFields.find(field => isFieldEmpty(field));

    if (missingField) {
      alert(`${missingField.charAt(0).toUpperCase() + missingField.slice(1)} is required.`);
      setIsDirty(true);
      inputRefs[missingField].current.focus();
    } else {
    
      if (userData.contactNo.length !== 11) {
        alert('Contact number must be exactly 11 digits.');
      } else {
        handleRegister();
      }
    }
  };

  return <div className="Register">
      <div className="reg-main-container">
        <h3>REGISTER</h3>
        <form>
          <div className="register-form-container">
            {['firstName', 'middleName', 'lastName', 'email'].map((field) => (
              <div key={field}>
                <div className="register-form-group">
                  <label>{field.charAt(0).toUpperCase() + field.slice(1).replace(/([A-Z])/g, ' $1')}:</label>
                  <input
                    type="text"
                    name={field}
                    ref={inputRefs[field]}
                    onChange={(e) => handleInputChange(e, field)}
                  />
                </div>
              </div>
            ))}

            <div>
              <div className="register-form-group">
                <label>Contact Number:</label>
                <input
                  type="tel"
                  name="contactNo"
                  ref={inputRefs.contactNo}
                  onChange={(e) => handleInputChange(e, 'contactNo')}
                />
                {contactError && <span className="errors">{contactError}</span>}
              </div>
            </div>

            <div>
              <div className="register-form-group">
                <label>Password:</label>
                <input
                  type={isPasswordVisible ? 'text' : 'password'}
                  name="password"
                  ref={inputRefs.password}
                  onChange={(e) => handleInputChange(e, 'password')}
                />
              </div>
            </div>

            <div>
              <div className="register-form-group">
                <label>Confirm Password:</label>
                <input
                  type={isPasswordVisible ? 'text' : 'password'}
                  name="confirmPassword"
                  ref={inputRefs.confirmPassword}
                  onChange={(e) => handleInputChange(e, 'confirmPassword')}
                />
              </div>
              {userData.password !== userData.confirmPassword && userData.confirmPassword && (
                <span className="errors">Passwords do not match</span>
              )}
            </div>

            <div className="show-password" onClick={togglePasswordVisibility}>
              {isPasswordVisible ? 'Hide' : 'Show'} Password
            </div>

            <div className="submit-container">
              <button
                type="button"
                disabled={status === 'loading'}
                onClick={() => {
                  if (status === 'loading') return;
                  handleSubmit();
                }}
              >
                {status === 'idle' ? 'Register' : 'Loading'}
              </button>
            </div>

            <div className="login-container">
              <a href="/">
                <medium>Login</medium>
              </a>
            </div>
          </div>
        </form>
      </div>
    </div>
};

export default Register;
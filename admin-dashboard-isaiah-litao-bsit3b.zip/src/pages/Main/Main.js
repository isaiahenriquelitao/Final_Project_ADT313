import { useEffect, useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import './Main.css';

function Main() {
  const accessToken = localStorage.getItem('accessToken');
  const navigate = useNavigate();
  const location = useLocation();
  const [activeLink, setActiveLink] = useState('');

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to log out?");
    if (confirmLogout) {
      localStorage.removeItem('accessToken');
      navigate('/');
      setActiveLink('');
    }
  };

  useEffect(() => {
    if (!accessToken) {
      handleLogout();
    }
    setActiveLink(location.pathname);
  }, [accessToken, navigate, location]);

  return (
    <div className='Main'>
      <div className='container'>
        <div className='navigation'>
          <ul>
            <li className={activeLink === '/main/dashboard' ? 'active' : ''}>
              <a href="/main/dashboard" onClick={() => setActiveLink('/main/dashboard')}>Dashboard</a>
            </li>
            <li className={activeLink === '/main/movies' ? 'active' : ''}>
              <a href='/main/movies' onClick={() => setActiveLink('/main/movies')}>Movies</a>
            </li>
            <li className='logout'>
              <a onClick={handleLogout}>Logout</a>
            </li>
          </ul>
        </div>
        <div className='outlet'>
          <Outlet />
        </div>
      </div>
    </div>
  );
}

export default Main;

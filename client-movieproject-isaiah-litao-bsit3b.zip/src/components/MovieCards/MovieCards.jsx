import './MovieCards.css';
import { useNavigate } from 'react-router-dom';
function MovieCards({ movie: movie }) {
  const navigate = useNavigate();
  const handleCardClick = () => {
    navigate(`/movie/${movie.id}`);
  };
  return (
    <div className='card' onClick={handleCardClick}>
      <img src={movie.posterPath} alt={movie.title} />
      <span>{movie.title}</span>
    </div>
  );
}
export default MovieCards;

import { useNavigate } from 'react-router-dom';
import './Home.css';
import { useEffect, useState } from 'react';
import axios from 'axios';
import MovieCards from '../../../../components/MovieCards/MovieCards';
import { useMovieContext } from '../../../../context/MovieContext';
import { useUserContext } from '../../../../context/UserContext';

const Home = () => {
  const { user } = useUserContext();
  const accessToken = localStorage.getItem('accessToken');
  const navigate = useNavigate();
  const [featuredMovie, setFeaturedMovie] = useState(null);
  const { movies, setMovies } = useMovieContext();

  console.log('movies:', movies);
  console.log('featuredMovie:', featuredMovie);

  const getMovies = () => {
    axios
      .get('/movies')
      .then((response) => {
        console.log('Fetched movies:', response.data);
        console.log('First movie:', response.data[0]);
        setMovies(response.data);
        const random = Math.floor(Math.random() * response.data.length);
        setFeaturedMovie(response.data[random]);
      })
      .catch((e) => console.error('Error fetching movies:', e));
  };

  useEffect(() => {
    getMovies();
  }, [setMovies]);

  useEffect(() => {
    if (movies.length) {
      const changeFeaturedMovie = () => {
        const random = Math.floor(Math.random() * movies.length);
        setFeaturedMovie(movies[random]);
      };
      const interval = setInterval(changeFeaturedMovie, 5000);
      return () => clearInterval(interval);
    }
  }, [movies]);

  return (
    <div className='main-container'>
      <header className='header'>
        <h1 className='page-title'>Movies</h1>
      </header>
      {featuredMovie && movies.length ? (
        <div className='featured-list-container'>
          <div
            className='featured-backdrop'
            style={{
              background: `url(${
                featuredMovie.backdropPath !==
                'https://image.tmdb.org/t/p/original/undefined'
                  ? featuredMovie.backdropPath
                  : featuredMovie.posterPath
              }) no-repeat center top`,
            }}
          >
            <span className='featured-movie-title'>{featuredMovie.title}</span>
          </div>
        </div>
      ) : (
        <div className='featured-list-container-loader'></div>
      )}
      <div className='list-container'>
        {movies.map((movie) => (
          <MovieCards
            key={movie.id}
            movie={movie}
            onClick={() => {
              navigate(`/view/${movie.id}`);
              setMovies([movie]);
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default Home;

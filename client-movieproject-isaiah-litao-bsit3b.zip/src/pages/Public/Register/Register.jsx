import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Register.css';

function Register() {
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [contactNo, setContactNo] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false); 
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (!firstName || !lastName || !email || !password || !confirmPassword || !contactNo) {
      setError('All fields are required.');
      return;
    }

    const data = { firstName, middleName, lastName, contactNo, email, password };

    try {
      const response = await fetch('/user/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        const { user, access_token } = await response.json();
        localStorage.setItem('accessToken', access_token);
        alert('Registration successful! Redirecting to movies page...');
        setTimeout(() => {
          navigate('/main/home');
        }, 2000); 
      } else {
        const { error } = await response.json();
        setError(error);
      }
    } catch (error) {
      console.error('Error:', error);
      setError('Registration failed. Please try again later.');
    }
  };

  const togglePassword = () => {
    setShowPassword(!showPassword);
  };

  return (
    <div className='register-container'>
      <div className='register-background'>
        <div className='register-form-container'>
          <h2 className='register-title'>Register</h2>
          <form className='register-form' onSubmit={handleRegister}>
            <div className='register-form-group'>
              <label>First Name</label>
              <input
                type='text'
                className='register-input'
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
                required
              />
            </div>
            <div className='register-form-group'>
              <label>Middle Name</label>
              <input
                type='text'
                className='register-input'
                value={middleName}
                onChange={(e) => setMiddleName(e.target.value)}
              />
            </div>
            <div className='register-form-group'>
              <label>Last Name</label>
              <input
                type='text'
                className='register-input'
                value={lastName}
                onChange={(e) => setLastName(e.target.value)}
                required
              />
            </div>
            <div className='register-form-group'>
              <label>Contact No</label>
              <input
                type='text'
                className='register-input'
                value={contactNo}
                onChange={(e) => setContactNo(e.target.value)}
                required
              />
            </div>
            <div className='register-form-group'>
              <label>Email</label>
              <input
                type='email'
                className='register-input'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className='register-form-group'>
              <label>Password</label>
              <input
                type={showPassword ? 'text' : 'password'} 
                className='register-input'
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            <div className='register-form-group'>
              <label>Confirm Password</label>
              <input
                type={showPassword ? 'text' : 'password'} 
                className='register-input'
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
            <div className='show-password-link' onClick={togglePassword}>
              <a href="#" className="show-password-link-text">
                {showPassword ? 'Hide Password' : 'Show Password'}
              </a>
            </div>
            {error && <p className='error'>{error}</p>}
            <button type='submit' className='register-button'>
              Register
            </button>
            <p className='login-link'>
              Already have an account? <Link to='/'>Login here</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Register;

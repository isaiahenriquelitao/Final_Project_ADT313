import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import './Login.css';
import { useUserContext } from '../../../context/UserContext';
import axios from 'axios';
import { useDebounce } from '../../../utils/hooks/useDebounce';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState('idle');
  const navigate = useNavigate();
  const { updateUser } = useUserContext();
  const debouncedEmail = useDebounce(email, 500);

  const handleLogin = async (e) => {
    e.preventDefault();
    setStatus('loading');
    setError(''); 

    if (!email || !password) {
      setError('Email and password are required.');
      setStatus('idle');
      return;
    }

    const data = { email, password };

    try {
      const response = await axios.post('/user/login', data, {
        headers: { 'Access-Control-Allow-Origin': '*' },
      });

      if (response.status === 200) {
        const { user, access_token } = response.data;
        const updatedUser = { ...user, role: user.role || 'user' };

        if (updatedUser.role === 'user') {
          updateUser(updatedUser, access_token);
          localStorage.setItem('accessToken', access_token);

          alert('Login successful!'); 
          setTimeout(() => {
            setStatus('idle');
            navigate('/main/home');
          }, 3000);
        } else {
          setError('Only users with the role "user" can log in.');
          alert('Only users with the role "user" can log in.');
        }
      } else {
        handleErrorResponse(response.status);
      }
    } catch (e) {
      console.error('Error:', e);
      setError('Login failed. Please try again later.');
    } finally {
      setStatus('idle');
    }
  };

  const handleErrorResponse = (status) => {
    switch (status) {
      case 401:
        setError('Incorrect password. Please try again.');
        alert('Incorrect password. Please try again.');
        break;
      case 400:
        setError('Incorrect email. Please check your email.');
        alert('Incorrect email. Please check your email.');
        break;
      default:
        setError('Login failed. Please try again later.');
        alert('Login failed. Please try again later.');
    }
  };

  useEffect(() => {
    const accessToken = localStorage.getItem('accessToken');
    if (accessToken) {
      navigate('/main/home');
    }
  }, [navigate]);

  return (
    <div className='login-container'>
      <div className='login-background'>
        <div className='login-form-container'>
          <h2 className='login-title'>Login</h2>
          <form className='login-form' onSubmit={handleLogin}>
<div className='log-form-group'>
  <label>Email</label>
  <input
    type='email'
    className='login-input'
    value={email}
    onChange={(e) => setEmail(e.target.value)}
    required
   
  />
</div>
<div className='log-form-group'>
  <label>Password</label>
  <input
    type='password'
    className='login-input'
    value={password}
    onChange={(e) => setPassword(e.target.value)}
    required
    
  />
</div>
            {error && <p className='error'>{error}</p>}
            <button type='submit' className='login-button' disabled={status === 'loading'}>
              {status === 'loading' ? 'Logging in...' : 'Login'}
            </button>
            <p className='register-link'>
              Don't have an account? <Link to='/register'>Register here</Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
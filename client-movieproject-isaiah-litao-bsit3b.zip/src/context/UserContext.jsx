import React, { createContext, useContext, useState, useEffect } from 'react';

const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [accessToken, setAccessToken] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    const storedAccessToken = localStorage.getItem('accessToken');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    if (storedAccessToken) {
      setAccessToken(storedAccessToken);
    }
  }, []);

  const updateUser = (newUser, newAccessToken) => {
    setUser(newUser);
    setAccessToken(newAccessToken);
    localStorage.setItem('user', JSON.stringify(newUser));
    localStorage.setItem('accessToken', newAccessToken);
  };

  return (
    <UserContext.Provider value={{ user, accessToken, updateUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUserContext = () => useContext(UserContext);
